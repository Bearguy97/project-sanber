# Sanber51-Cypress-Kelompok 13

Irfan : Register Feature
Putri : View and Update Shopping Cart
Angel : Choose Product(s)
Pasha : Login
Adit : Checkout
